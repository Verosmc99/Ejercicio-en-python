def f():
    broken_code
    print('fuckit chaining works')

for

let's just assume this is a big module of shitty code.

x = y
y = x
1 / 0 # Oh shhhiiiiiii

var = "Are you proud of what you've done?"